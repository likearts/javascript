import { HwsliderDirective } from './hwslider.directive';

describe('HwsliderDirective', () => {
  it('should create an instance', () => {
    const directive = new HwsliderDirective();
    expect(directive).toBeTruthy();
  });
});
