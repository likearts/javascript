export class HwswipeProvider {

}
