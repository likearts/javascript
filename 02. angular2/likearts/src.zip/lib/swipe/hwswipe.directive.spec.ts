import { HwSwipeDirective } from './hwswipe.directive';

describe('HwSwipeDirective', () => {
  it('should create an instance', () => {
    const directive = new HwSwipeDirective();
    expect(directive).toBeTruthy();
  });
});
