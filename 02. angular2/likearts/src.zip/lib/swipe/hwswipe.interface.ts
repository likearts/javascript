export interface HwSwipeInterface {
  swipeController(type:any):void
}
